GUSTAVO AUAD PICCOLI - 00275858 - Turma: A
JÚLIA DEL PINO RITTMANN - 00262512 - Turma: A 
NÍKOLAS PADÃO SCHUSTER - 00323741 - Turma: A

O grupo não utilizou bibliotecas do python que necessitem ser instaladas. 

Foram criados os arquivos:
    1) Tree.py - Gerencia as fronteiras dos diferentes algoritmos, com as funções de Tree, salvamos as fronteiras como árvores, tornando a execução dos algoritmos muito mais rápidas
    2) heapqModified.py - Gerencia as operações do Heap utilizado no algoritmo astar_manhattan


Testes com "2_3541687":
    1) bfs:
        - Nós expandidos = 214017
        - Tempo = 3.2765443325042725
        - Custo = 23
    2) dfs:
        - Nós expandidos = 290712
        - Tempo = 1.8136184215545654
        - Custo = 101601
    3) manhattan:
        - Nós expandidos = 2444
        - Tempo = 0.046875953674316406
        - Custo = 23
    4) hamming:
        - Nós expandidos = 20321
        - Tempo = 0.24158048629760742
        - Custo = 23